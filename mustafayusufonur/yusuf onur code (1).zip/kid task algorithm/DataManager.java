package com.kidtask.model;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * File-based storage for KidTask entities using .txt files.
 * Manages: users.txt, tasks.txt, AND wishes.txt
 */
public final class DataManager {
    private static final String DATA_DIR = "data";
    private static final String USERS_FILE = DATA_DIR + File.separator + "users.txt";
    private static final String TASKS_FILE = DATA_DIR + File.separator + "tasks.txt";
    private static final String WISHES_FILE = DATA_DIR + File.separator + "wishes.txt"; // Yeni dosya
    
    private static final List<User> USERS = new ArrayList<>();
    private static final List<Task> TASKS = new ArrayList<>();
    private static final List<Wish> WISHES = new ArrayList<>(); // Yeni liste
    private static boolean initialized = false;

    private DataManager() {}

    public static void initialize() {
        if (initialized) return;
        
        try {
            Path dataPath = Paths.get(DATA_DIR);
            if (!Files.exists(dataPath)) Files.createDirectories(dataPath);
            
            loadUsers();
            loadTasks();
            loadWishes(); // Dilekleri yükle
            
            initialized = true;
            System.out.println("DataManager initialized. Users: " + USERS.size() + ", Tasks: " + TASKS.size() + ", Wishes: " + WISHES.size());
        } catch (Exception e) {
            e.printStackTrace();
            initialized = true; 
        }
    }

    public static void saveAll() {
        try {
            saveUsers();
            saveTasks();
            saveWishes(); // Dilekleri kaydet
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- USERS LOAD/SAVE (Aynı kaldı, sadece kısaltarak ekliyorum) ---
    private static void loadUsers() throws IOException {
        USERS.clear();
        File file = new File(USERS_FILE);
        if (!file.exists()) return;
        
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("#")) continue;
                User user = parseUser(line); // parseUser mantığı aynı kaldı
                if (user != null) USERS.add(user);
            }
        }
    }

    private static void saveUsers() throws IOException {
        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(USERS_FILE), StandardCharsets.UTF_8))) {
            writer.println("# TYPE|ID|NAME|EMAIL|USERNAME|PASSWORD|POINTS");
            for (User user : USERS) writer.println(serializeUser(user));
        }
    }

    // --- TASKS LOAD/SAVE (GÜNCELLENDİ: Tarih ve Rating eklendi) ---
    private static void loadTasks() throws IOException {
        TASKS.clear();
        File file = new File(TASKS_FILE);
        if (!file.exists()) return;
        
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("#")) continue;
                // Format: TITLE|DESC|POINTS|DUEDATE|RATING|STATUS|ASSIGNEE_ID
                String[] parts = line.split("\\|");
                if (parts.length < 7) continue;

                String title = parts[0];
                String desc = parts[1];
                int points = Integer.parseInt(parts[2]);
                String dueDate = parts[3];
                int rating = Integer.parseInt(parts[4]);
                TaskStatus status = TaskStatus.valueOf(parts[5]);
                String assigneeId = parts[6];

                Child assignee = null;
                for (User u : USERS) {
                    if (u instanceof Child && u.getId().equals(assigneeId)) {
                        assignee = (Child) u;
                        break;
                    }
                }
                
                Task t = new Task(title, desc, points, dueDate, status, assignee);
                t.setRating(rating);
                TASKS.add(t);
            }
        }
    }

    private static void saveTasks() throws IOException {
        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(TASKS_FILE), StandardCharsets.UTF_8))) {
            writer.println("# TITLE|DESC|POINTS|DUEDATE|RATING|STATUS|ASSIGNEE_ID");
            for (Task t : TASKS) {
                String aid = (t.getAssignee() != null) ? t.getAssignee().getId() : "";
                String dd = (t.getDueDate() != null) ? t.getDueDate() : "null";
                writer.printf("%s|%s|%d|%s|%d|%s|%s%n", 
                    t.getTitle(), t.getDescription(), t.getPoints(), dd, t.getRating(), t.getStatus(), aid);
            }
        }
    }

    // --- WISHES LOAD/SAVE (YENİ EKLENDİ) ---
    private static void loadWishes() throws IOException {
        WISHES.clear();
        File file = new File(WISHES_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("#")) continue;
                // Format: NAME|COST|STATUS|CHILD_ID
                String[] parts = line.split("\\|");
                if (parts.length < 4) continue;

                String name = parts[0];
                int cost = Integer.parseInt(parts[1]);
                String status = parts[2];
                String childId = parts[3];

                Child owner = null;
                for (User u : USERS) {
                    if (u instanceof Child && u.getId().equals(childId)) {
                        owner = (Child) u;
                        break;
                    }
                }

                Wish w = new Wish(name, cost, owner);
                w.setStatus(status);
                WISHES.add(w);
            }
        }
    }

    private static void saveWishes() throws IOException {
        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(WISHES_FILE), StandardCharsets.UTF_8))) {
            writer.println("# NAME|COST|STATUS|CHILD_ID");
            for (Wish w : WISHES) {
                String cid = (w.getChild() != null) ? w.getChild().getId() : "";
                writer.printf("%s|%d|%s|%s%n", w.getName(), w.getCost(), w.getStatus(), cid);
            }
        }
    }

    // --- YARDIMCI METOTLAR ---
    // User parse/serialize metodları aynen kalacak (Burada yer kaplamasın diye kısalttım, önceki kodunuzdakileri kullanın)
    private static User parseUser(String line) {
         String[] parts = line.split("\\|");
        if (parts.length < 4) return null;
        String type = parts[0]; String id = parts[1]; String name = parts[2]; String email = parts[3];
        // Basitleştirilmiş örnek, orijinal detaylı parseUser kodunuzu buraya koyun
        if ("CHILD".equals(type)) {
            int pts = (parts.length > 6) ? Integer.parseInt(parts[6]) : 0;
            return new Child(id, name, email, pts, parts.length>4?parts[4]:"", parts.length>5?parts[5]:"");
        } else if ("PARENT".equals(type)) return new Parent(id, name, email);
        else return new Teacher(id, name, email);
    }

    private static String serializeUser(User u) {
        String base = u.getId() + "|" + u.getName() + "|" + u.getEmail() + "|" + (u.getUsername()!=null?u.getUsername():"") + "|" + (u.getPassword()!=null?u.getPassword():"");
        if (u instanceof Child) return "CHILD|" + base + "|" + ((Child)u).getTotalPoints();
        else if (u instanceof Parent) return "PARENT|" + base;
        else return "TEACHER|" + base;
    }

    // List Accessors
    public static List<User> getUsers() { ensureInitialized(); return USERS; }
    public static List<Task> getTasks() { ensureInitialized(); return TASKS; }
    public static List<Wish> getWishes() { ensureInitialized(); return WISHES; }

    public static void addUser(User u) { ensureInitialized(); USERS.add(u); saveAll(); }
    public static void addTask(Task t) { ensureInitialized(); TASKS.add(t); saveAll(); }
    public static void addWish(Wish w) { ensureInitialized(); WISHES.add(w); saveAll(); }
    
    // Auth
    public static User authenticate(String user, String pass, String role) {
        ensureInitialized();
        for (User u : USERS) {
            if (u.getUsername().equals(user) && u.getPassword().equals(pass)) {
                if (role.equals("CHILD") && u instanceof Child) return u;
                if (role.equals("PARENT") && u instanceof Parent) return u;
                if (role.equals("TEACHER") && u instanceof Teacher) return u;
            }
        }
        return null;
    }

    private static void ensureInitialized() { if (!initialized) initialize(); }
}