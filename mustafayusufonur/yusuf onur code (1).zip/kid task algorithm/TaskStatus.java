package com.kidtask.model;

public enum TaskStatus {
    PENDING,
    APPROVED,
    REJECTED
}

