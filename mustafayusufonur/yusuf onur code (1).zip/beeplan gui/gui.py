import sys
import os
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QTableWidget, QTableWidgetItem, 
                             QFileDialog, QMessageBox, QLabel, QHeaderView, QAbstractItemView)
from PyQt5.QtGui import QColor, QFont
from PyQt5.QtCore import Qt

# Önceki dosyalarımızı import ediyoruz
from data_loader import DataLoader
from beeplan_engine import SchedulerEngine, SchedulingConflictError, DAYS_MAP

class BeePlanWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("BeePlan - Course Scheduler")
        self.setGeometry(100, 100, 1000, 700)
        
        # Veri saklama
        self.courses = {}
        self.rooms = {}
        self.instructors = {}
        self.engine = None
        self.schedule = []

        # Arayüzü Kur
        self.init_ui()

    def init_ui(self):
        # Ana Widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)

        # --- Üst Panel (Butonlar) ---
        top_layout = QHBoxLayout()
        
        self.btn_load = QPushButton("📂 Load JSON Data")
        self.btn_load.setStyleSheet("background-color: #3498db; color: white; font-weight: bold; padding: 10px;")
        self.btn_load.clicked.connect(self.load_data)
        
        self.btn_gen = QPushButton("⚙️ Generate Schedule")
        self.btn_gen.setStyleSheet("background-color: #2ecc71; color: white; font-weight: bold; padding: 10px;")
        self.btn_gen.clicked.connect(self.generate_schedule)
        self.btn_gen.setEnabled(False) # Veri yüklenmeden pasif

        self.btn_report = QPushButton("📄 View Report")
        self.btn_report.setStyleSheet("background-color: #9b59b6; color: white; font-weight: bold; padding: 10px;")
        self.btn_report.clicked.connect(self.show_report)
        self.btn_report.setEnabled(False)

        top_layout.addWidget(self.btn_load)
        top_layout.addWidget(self.btn_gen)
        top_layout.addWidget(self.btn_report)
        
        # Bilgi Etiketi
        self.lbl_status = QLabel("Welcome to BeePlan. Please load data.")
        self.lbl_status.setAlignment(Qt.AlignCenter)
        self.lbl_status.setStyleSheet("color: gray; margin: 5px;")

        main_layout.addLayout(top_layout)
        main_layout.addWidget(self.lbl_status)

        # --- Tablo (Timetable) ---
        self.table = QTableWidget()
        self.setup_table()
        main_layout.addWidget(self.table)

    def setup_table(self):
        # Sütunlar: Pazartesi - Cuma (Hafta sonu opsiyonel eklenebilir)
        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
        self.table.setColumnCount(len(days))
        self.table.setHorizontalHeaderLabels(days)
        
        # Satırlar: 09:00 - 17:00 (Yarım saatlik dilimler)
        # 09:00'dan 17:00'ye kadar -> 8 saat * 2 = 16 dilim
        start_hour = 9
        slots = []
        for h in range(start_hour, 18):
            slots.append(f"{h:02d}:00")
            if h != 17: slots.append(f"{h:02d}:30")
        
        self.table.setRowCount(len(slots))
        self.table.setVerticalHeaderLabels(slots)
        
        # Tablo Ayarları
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers) # Düzenlemeyi kapat
        self.table.setSelectionMode(QAbstractItemView.NoSelection) # Seçimi kapat

    def load_data(self):
        fname, _ = QFileDialog.getOpenFileName(self, 'Open JSON File', os.getcwd(), "JSON Files (*.json)")
        if fname:
            try:
                self.courses, self.rooms, self.instructors = DataLoader.load_json(fname)
                self.engine = SchedulerEngine(self.courses, self.rooms, self.instructors)
                
                self.lbl_status.setText(f"Loaded: {len(self.courses)} Courses, {len(self.instructors)} Instructors")
                self.btn_gen.setEnabled(True)
                QMessageBox.information(self, "Success", "Data loaded successfully!")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Could not load data:\n{e}")

    def generate_schedule(self):
        if not self.engine: return
        
        self.lbl_status.setText("Generating schedule... Please wait.")
        QApplication.processEvents() # Arayüzün donmasını engelle
        
        try:
            self.schedule = self.engine.generate_schedule()
            self.update_timetable_view()
            self.lbl_status.setText("Schedule generated successfully!")
            self.btn_report.setEnabled(True)
            QMessageBox.information(self, "Success", "Schedule generated without conflicts!")
        except SchedulingConflictError as e:
            self.lbl_status.setText("Failed to generate schedule.")
            QMessageBox.warning(self, "Conflict Error", str(e))
        except Exception as e:
            self.lbl_status.setText("Unexpected Error.")
            QMessageBox.critical(self, "Error", str(e))

    def update_timetable_view(self):
        self.table.clearContents()
        
        # Renk Paleti (Dersleri ayırmak için)
        colors = [QColor(255, 235, 59), QColor(130, 224, 170), QColor(133, 193, 233), 
                  QColor(245, 176, 65), QColor(215, 189, 226), QColor(241, 148, 138)]

        for slot in self.schedule:
            # Sütun İndeksi (Gün)
            col_idx = DAYS_MAP.get(slot.day)
            if col_idx is None or col_idx > 4: continue # Sadece Pzt-Cuma gösteriyoruz

            # Satır İndeksi (Saat)
            # Başlangıç saati 09:00 kabul ettik. (9 * 60 = 540 dakika)
            start_min = slot.start_time.hour * 60 + slot.start_time.minute
            base_min = 9 * 60 # 09:00
            
            row_idx = (start_min - base_min) // 30 # 30 dakikalık dilimler
            
            if row_idx < 0 or row_idx >= self.table.rowCount(): continue

            # Süreye göre kaç hücre kaplayacak?
            span_rows = slot.duration_minutes // 30
            
            # Hücre İçeriği
            course = self.courses[slot.course_id]
            instr = self.instructors[slot.instructor_id]
            room = self.rooms[slot.room_id]
            
            text = f"{course.name}\n({room.type.value} - {room.id})\n{instr.name}"
            
            # Hücreyi Oluştur
            item = QTableWidgetItem(text)
            item.setBackground(colors[slot.course_id % len(colors)])
            item.setTextAlignment(Qt.AlignCenter)
            item.setFont(QFont("Arial", 9, QFont.Bold))
            
            self.table.setItem(row_idx, col_idx, item)
            
            # Hücre Birleştirme (Span)
            if span_rows > 1:
                self.table.setSpan(row_idx, col_idx, span_rows, 1)

    def show_report(self):
        msg = "--- SCHEDULE REPORT ---\n\n"
        # Basit bir metin raporu
        sorted_schedule = sorted(self.schedule, key=lambda x: (DAYS_MAP.get(x.day, 7), x.start_time))
        
        for s in sorted_schedule:
             c_name = self.courses[s.course_id].name
             i_name = self.instructors[s.instructor_id].name
             msg += f"[{s.day} {s.start_time.strftime('%H:%M')}] {c_name} | {i_name}\n"
             
        QMessageBox.information(self, "Report", msg)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = BeePlanWindow()
    window.show()
    sys.exit(app.exec_())